import React from 'react';
import './App.css';
import Select from "react-select";
import Page from "./Data/Menus.js"


function App() {



  return (
    <div className="App">
      <header className="App-header">
     <Page/>  
      </header>       
    </div>
  );
}
export default App;
