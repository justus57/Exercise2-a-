import React,{useState} from 'react';
import Multiselect from 'multiselect-react-dropdown';

function menuItem (){
    const optionList = [
        {
           "name":"Salad",
           "choices":[
              {
                 "name":"Santa Fe"
              },
              {
                 "name":"Greek"
              },
              {
                 "name":"Asian"
              }
           ],
           "related":[
              {
                 "name":"Dressing",
                 "choices":[
                    {
                       "name":"Italian"
                    },
                    {
                       "name":"Blue Cheese"
                    },
                    {
                       "name":"Ranch"
                    }
                 ]
              },
              {
                 "name":"Bread",
                 "choices":[
                    {
                       "name":"Italian"
                    },
                    {
                       "name":"Flat"
                    },
                    {
                       "name":"Sourdough"
                    }
                 ]
              }
           ]
        },
        {
           "name":"Entree",
           "choices":[
              {
                 "name":"Steak"
              },
              {
                 "name":"Salmon"
              },
              {
                 "name":"Rice"
              }
           ],
           "related":[
              
           ]
        },
        {
           "name":"Soup",
           "choices":[
              {
                 "name":"Minestrone"
              },
              {
                 "name":"Hot and sour"
              },
              {
                 "name":"Miso"
              }
           ],
           "related":[
              {
                 "name":"Bread",
                 "choices":[
                    {
                       "name":"Breadsticks"
                    }
                 ]
              }
           ]
        }
     ];
     const data =JSON.parse(JSON.stringify(optionList));
    
    const [options,setoptions] =useState([data]);
    for (const option in options) {
        {options.map((option, index) => (
            <option key={index} value={index}>
              {option.name}
            </option>
            ))}
            const datavalue = option;
     }
    
    return (<React.Fragment>
       
            <div className="row">
                <div className="col-em-12">
                    <h1 className="mt-3">Restaurant MENU</h1>
                    <form className="row g-3">
                        <Multiselect
                        isObject={false}
                        options={datavalue}      
                        showCheckbox                       
                        />
                    </form>
                </div>
            </div>
      
    </React.Fragment>

    );

}
export default menuItem;